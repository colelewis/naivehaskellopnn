module Main (main) where
import System.Random
import Control.Monad.State
-- import Lib

-- helper functions
dot :: Num a => [a] -> [a] -> a
dot _ [] = 0
dot [] _ = 0
dot (x:xs) (y:ys) = (x * y) + dot xs ys

linear :: Num a => [a] -> [a] -> a -> a -- our means of forward propagation, pushes input data forward through hidden layer(s) to the output layer
linear x weights bias = dot x weights + bias

sigmoid :: Floating a => a -> a -- the activation function, returns a value between 0 and 1 from a weighted set of inputs
sigmoid x = 1.0 / (1.0 + exp(-x))

dSigmoid :: Floating a => a -> a -- during back propagation, we need the derivative of the activation function in calculating gradients
dSigmoid x = sigmoid x * (1 - sigmoid x)

absoluteUnaveragedSum :: Num a => [a] -> [a] -> a
absoluteUnaveragedSum _ [] = 0
absoluteUnaveragedSum [] _ = 0
absoluteUnaveragedSum (a:as) (e:es) = abs (a - e) + absoluteUnaveragedSum as es

meanAbsoluteError :: Fractional a => [a] -> [a] -> a
meanAbsoluteError actual experimental = absoluteUnaveragedSum actual experimental / fromIntegral(length actual)

sortOutput :: (Ord a1, Fractional a1, Num a2) => a1 -> a2 -- converts the inference output into either 0 or 1 from the raw output of infer
sortOutput x
    | x < 0.5 = 0
    | otherwise = 1

-- some operator truth tables; basic enough to include as matrices here, used for training the model
-- [x, y, x OPERATOR y]
and = [[0, 0, 0], [0, 1, 0], [1, 0, 0], [1, 1, 1]]
or = [[0, 0, 0], [0, 1, 1], [1, 0, 1], [1, 1, 1]]
xor = [[0, 0, 0], [0, 1, 1], [1, 0, 1], [1, 1, 0]]
nor  = [[0, 0, 1], [0, 1, 0], [1, 0, 0], [1, 1, 0]]

randomWeights :: IO [[Double]]
randomWeights = do
    g <- newStdGen
    let s = [x | x<-randoms g :: [Double], x < 0.1]
    return [take 2 s]

{--
    the neural network will take two input vectors, so we need two hidden weights: one for each input.
    each hidden weight will be randomly initialized to meet the expectation of our optimization algorithm: stochastic gradient descent (SGD)
    randomly initialized weights also help with what is called "symmetry breaking"; when all weights are initialized equally, it can become difficult for them to change independently when training
    research into the topic suggests that small values between 0 and 0.1 make for the best starting weights for SGD
    self.hidden_weights = np.array([[np.random.uniform(0, 0.1), np.random.uniform(0, 0.1)]]) # initialize two random weights between 0 and 0.1 (inclusive of 0.1)
--}

hiddenWeights :: IO [[Double]]
hiddenWeights = randomWeights

outputWeights :: IO [[Double]]
outputWeights = randomWeights

hiddenBias :: [[Double]]
hiddenBias = [replicate 2 0.0]

outputBias :: [[Double]]
outputBias = [replicate 2 0.0]

{--
    in our feedforward neural network, data is fed forward through our input layer -> hidden layer -> output layer
    the function below is meant to calculate outputs from the network by summing the dot product of inputs and weights with the bias
    unlike infer(), this method returns both 1st and 2nd layer outputs since back propagation will need both to determine how to shift weights
    note: this method will be used for making predictions as well; a2 will be the interpretable result from the output layer
--}
forwardPropagate :: Floating a => [a] -> [a] -> [a] -> a -> a -> [a]
forwardPropagate inputVector hidden_weights output_weights hidden_bias output_bias = [z1, a1, z2, a2] where
    z1 = linear inputVector hidden_weights hidden_bias
    a1 = sigmoid z1
    z2 = linear [a1] output_weights output_bias
    a2 = sigmoid z2

main :: IO ()
main = do
    putStrLn "test"
